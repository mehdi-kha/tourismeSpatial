#include <string.h>
#include <stdlib.h>

#include "modele.h"

int NB_ZONE=4;
int NB_CROISIERE=3;

typedef struct contrainte* contrainte;
typedef struct destination _destination;
typedef struct croisiere _croisiere;
typedef struct croisieres _croisieres;
typedef struct maillon* maillon;

struct contrainte {
	destination dest_suivante;
	contrainte next_contrainte;
};


struct croisieres
{
	croisiere* liste;
	int size;
	int current;
};


struct maillon
{
	destination dest;
	struct maillon* next;
};


struct croisiere
{
	int indice;
	char* nom;
	int quota;
	int quota_total;
	maillon* destination;
	voyageur* v_selectionnes;
	int parcour_v_selectionnes;
};

struct destination
{
	char* nom;
	int* quota;
	contrainte contrainte;
};


croisiere get_first_croisiere_org(croisieres cs)
{
	if(cs->size<2)
		return NULL;
	cs->current=1;
	return cs->liste[1];
}

croisiere get_next_croisiere(croisieres cs)
{
	cs->current++;
	if (cs->size == cs->current)
	{
		return NULL;
	}
	return cs->liste[cs->current];
}

int get_quota(croisiere c, destination d)
{
	return (d->quota)[c->indice];
}

int get_quota_croisiere(croisiere c)
{
	return c->quota;
}

int push_voyageur_croisiere(voyageur v, croisiere c)
{
	if(c->quota <= 0)
		return 1;
	if( c->v_selectionnes == NULL )
		c->v_selectionnes=calloc(c->quota_total, sizeof(voyageur));
	c->v_selectionnes[c->quota_total - c->quota]=v;
	c->quota--;
	return 0;
}

voyageur get_first_voyageur(croisiere c)
{
	if(c->v_selectionnes ==NULL)
		return NULL;
	c->parcour_v_selectionnes=0;
	return (c->v_selectionnes)[0];
}
voyageur get_next_voyageur(croisiere c)
{
	c->parcour_v_selectionnes++;
	if (c->parcour_v_selectionnes > (c->quota_total - c->quota))
	{
		return NULL;
	}
	return (c->v_selectionnes)[c->parcour_v_selectionnes];
}

croisieres newCroisieres()
{
	croisieres cs = malloc(sizeof(_croisieres));
	cs->liste=NULL;
	cs->size=0;
	cs->current=0;
	return cs;
}



croisiere newCroisiere(char* nom, int quota, croisieres cs)
{
	croisiere c = malloc(sizeof(_croisiere));
	c->nom=nom;
	c->quota_total=quota;
	c->quota=quota;
	c->destination=NULL;
	c->v_selectionnes=NULL;
	c->parcour_v_selectionnes=0;
	
	cs->liste=realloc(cs->liste, ((cs->size)+1)*sizeof(croisiere));
	cs->liste[cs->size]=c;
	cs->size=cs->size+1;
	
	return c;
}

destination search_destination(char* nom, croisieres cs){
	int i,z;
	for (i = 0; i < cs->size ; i++)
	{
		croisiere c = cs->liste[i];
		if( c->destination != NULL){
			for (z = 0; z < NB_ZONE ; z++)
			{
				maillon m = (c->destination)[z];
				
				while(m != NULL){
					if( 0 == strcmp( (m->dest)->nom, nom))
						return m->dest;
					m=m->next;
				}
			}
		}
	}
	return NULL;
}


void pushDestination(char* nomdest, int quota, croisiere c, int zone, croisieres cs)
{
	destination d = search_destination(nomdest,cs);
	if(d==NULL){
		d = malloc(sizeof(_destination));
		d->quota=malloc(sizeof(int)*(NB_CROISIERE+1));
		d->nom=nomdest;
	}
	d->quota[c->indice]=quota;
	maillon m = malloc(sizeof(struct maillon));
	if(c->destination == NULL){
		c->destination = calloc( NB_ZONE, sizeof(maillon));

	}
	m->next=(c->destination)[zone];
	m->dest=d;
	(c->destination)[zone]=m;
	
}

croisiere getCroisiere(char* nom, croisieres cs)
{
	int i;
	for (i = 0; i < cs->size; i++)
	{
		if(0==strcmp(((cs->liste)[i])->nom, nom))
			return (cs->liste)[i];
	}
	return NULL;
}

char* get_destination_nom(destination d)
{
	return d->nom;	
}

char* get_croisiere_nom(croisiere c)
{
	return c->nom;
}

/********************************************************************************************************************************************/

struct info_voyageur
{
	voyageur first;
	voyageur current;
};

typedef struct info_voyageur _info_voyageur;

struct voyageur
{
	char* nom;
	char* prenom;
	int priorite;
	croisiere* croisiere;
	destination* choix_destination;
	destination* destination_affectee;
	voyageur suivant;
	int nb_choix;
};

typedef struct voyageur _voyageur;

info_voyageur infoVoyageur()
{
	info_voyageur iv = (info_voyageur) malloc(sizeof( _info_voyageur ));
	iv->first=NULL;
	iv->current=NULL;
	return iv;
}

voyageur info_voyageurFirst(info_voyageur iv)
{
	iv->current=iv->first;
	return iv->first;
}


voyageur info_voyageurNext(info_voyageur iv)
{

	iv->current = (iv->current)->suivant;
	return iv->current;

}


void addVoyageur_tri_prio(info_voyageur iv, char* nom, char* prenom, int priorite)
{
	voyageur v=iv->first;
	voyageur ancien =v;
	while(  v != NULL && priorite > v->priorite)
	{
		ancien=v;
		v=v->suivant;
	}
	voyageur new = malloc(sizeof( struct voyageur ));
	new->nom=nom;
	new->prenom=prenom;
	new->priorite=priorite;
	new->croisiere=NULL;
	new->choix_destination=NULL;
	new->destination_affectee=NULL;
	new->suivant=v;
	new->nb_choix=0;


	if(iv->first == NULL)
		iv->first=new;
	else
		if(priorite < (iv->first)->priorite)
			iv->first=new;
		else
			ancien->suivant=new;
}

void addChoice(voyageur v, char** tab_croisiere, char** tab_destination, int taille_tab_croisiere, int taille_tab_destination, croisieres cs )
{
	int i;
	v->nb_choix=taille_tab_croisiere;
	v->croisiere=malloc(taille_tab_croisiere*sizeof(croisiere));
	for (i = 0; i < taille_tab_croisiere; i++)
	{
		croisiere c = getCroisiere(tab_croisiere[i],cs);
		(v->croisiere)[i]=c;
	}

	v->choix_destination=malloc(NB_ZONE*NB_CROISIERE*sizeof(destination));
	for (i = 0; i < NB_CROISIERE; i++)
	{
		
		int z;
		for (z = 0; z < NB_ZONE; z++)
		{
			destination d = search_destination(tab_destination[i*NB_ZONE+z],cs);
			(v->choix_destination)[i*NB_ZONE+z]=d;
		}
	}
}

voyageur get_voyageur(char* nom, char* prenom, info_voyageur iv)
{
	voyageur v=iv->first;
	while(v != NULL)
	{
		if (strcmp(nom,v->nom)==0 && strcmp(prenom,v->prenom)==0)
		{
			return v;
		}
		v=v->suivant;
	}
	return NULL;
}

char* get_nom_voyageur(voyageur v)
{
	return v->nom;
}

char* get_prenom_voyageur(voyageur v)
{
	return v->prenom;
}

int get_priorite(voyageur v){
	return v->priorite;
}


croisiere* get_choix_croisiere(voyageur v, int* taille)
{
	*taille = v->nb_choix;
	return v->croisiere;
}

destination* get_choix_destination(voyageur v)
{
	return v->choix_destination;
}

int getZone(destination d, croisieres cs){
	int i,z;
	for (i = 0; i < cs->size ; i++)
	{
		croisiere c = cs->liste[i];
		if( c->destination != NULL){
			for (z = 0; z < NB_ZONE ; z++)
			{
				maillon m = (c->destination)[z];
				
				while(m != NULL){
					if( (m->dest)==d )
						return z;
					m=m->next;
				}
			}
		}
	}
	return 0;
}


int newContrainte(destination d, destination dcontrainte){

}

