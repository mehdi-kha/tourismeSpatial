

typedef struct croisiere* croisiere;
typedef struct croisieres* croisieres;
typedef struct destination* destination;


typedef struct info_voyageur* info_voyageur;
typedef struct voyageur* voyageur;

/*______________________________________________________croisiere_________________________________________________________________*/




/*********************création*******************/

/*t
@ assigns
@ requires
@ ensures
*/
croisieres newCroisieres();

/*t
@ assigns
@ requires
@ ensures
*/
croisiere newCroisiere(char* nom, int quota, croisieres cs);

/*t
@ requires
@ assigns
@ ensures
*/
void pushDestination(char* nomdest, int quota, croisiere, int zone, croisieres);

/*t
@ assigns -
@ requires un voyageur , une croisiere
@ ensures	retourne 0 si le voyageur à été ajouter et decrémente le quota, 1 sinon (si il n'y a plus de place dans la croisiere)
*/
int push_voyageur_croisiere(voyageur, croisiere);

/*******************Parcours*****************/

/*t
@ assigns
@ requires
@ ensures retourne la premiere croisiere organisee ou NULL
*/
croisiere get_first_croisiere_org(croisieres);

/*t
@ assigns
@ requires
@ ensures retourne la croisiere organisee suivante et avance d'un pas ou NULL
*/
croisiere get_next_croisiere(croisieres);

/*t
@ assigns
@ requires
@ ensures
*/
voyageur get_first_voyageur(croisiere);

/*t/2
@ assigns
@ requires
@ ensures
*/
voyageur get_next_voyageur(croisiere);


/*******************Getter*******************/

/*t
@ assigns
@ requires
@ ensures
*/
int get_quota(croisiere, destination);

/*t
@ assigns
@ requires
@ ensures
*/
int get_quota_croisiere(croisiere);

/*t
@ assigns
@ requires
@ ensures
*/
croisiere getCroisiere(char* nom, croisieres cs);


/*t
@ assigns
@ requires
@ ensures
*/
char* get_destination_nom(destination);

/*t
@ assigns
@ requires
@ ensures
*/
char* get_croisiere_nom(croisiere);

/*
@ assigns
@ requires
@ ensures
*/
void get_dest_zone();

/*t
@ assigns
@ requires
@ ensures
*/
destination search_destination(char* nom, croisieres cs);


/*______________________________________________________________Voyageur_________________________________________________________*/


/**************création**************/

/*t
@ assigns	taille de info_voyageur
@ requires	-
@ ensures	retourne un pointeur vers un info_voyageur vide
*/
info_voyageur infoVoyageur();

/*t
@ assigns	taille de voyageur
@ requires	un voyageur
@ ensures	ajoute un voyageur à la liste chainé info_voyageur
*/
void addVoyageur_tri_prio(info_voyageur, char* nom, char* prenom, int priorite);

/*1/2t
@ assigns
@ requires
@ ensures faire attention si on tente d'inserer une croisiere qui existe pas insere NULL
*/
void addChoice(voyageur, char* tab_croisiere[], char* tab_destination[], int taille_tab_croisiere, int taille_tab_destination, croisieres cs );


/***********Parcours**************/

/*t
@ assigns	-
@ requires	un pointeur info_voyageur
@ ensures	retourne un poiteur vers le premier voyageur de la liste et place le voyageur courrant à celui ci.
*/

voyageur info_voyageurFirst(info_voyageur);
/*t
@ assigns	-
@ requires	un pointeur info_voyageur
@ ensures	retourne un poiteur vers le voyageur suivant et place le voyaeur courrant à celui ci, ou retourne NULL et met le current à NULL
*/
voyageur info_voyageurNext(info_voyageur);


/********************Getter*******************/

/*t
@ assigns -
@ requires char* nom,prenom	
@ ensures retourne le voyageur ou NULL si il n'existe pas
*/
voyageur get_voyageur(char* nom, char* prenom, info_voyageur);

/*t
@ assigns -
@ requires un voyageur
@ ensures	retourne le nom du voyageur
*/
char* get_nom_voyageur(voyageur);

/*t
@ assigns -
@ requires un voyageur
@ ensures	retourne le prenom du voyageur
*/
char* get_prenom_voyageur(voyageur);

/*t
@ assigns -
@ requires un voyageur
@ ensures	retourne la pririté du voyageur
*/
int get_priorite(voyageur);

/*t
@ assigns
@ requires
@ ensures retourne un tableau de croisiere choisit de taille "taille"  
*/
croisiere* get_choix_croisiere(voyageur, int* taille);

/*
@ assigns
@ requires
@ ensures
*/
destination* get_choix_destination(voyageur); 

/*
@ assigns
@ requires
@ ensures
*/
void attribDest(voyageur nomVoyageur, destination nomDestination, int zone);

/*t
@ assigns
@ requires
@ ensures
*/
int getZone(destination, croisieres);

/*
@ assigns
@ requires
@ ensures
*/
int newContrainte(destination nomDestination, destination destinationContrainte);













