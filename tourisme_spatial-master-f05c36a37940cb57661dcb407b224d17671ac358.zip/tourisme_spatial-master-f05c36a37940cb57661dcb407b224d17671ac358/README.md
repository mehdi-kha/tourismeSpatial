Jusqu'au 8 avril : Définition des modules, choix du langage, Github
 
Jusqu'au 15 avril : Définition des rôles, rédaction du cahier des charges avec présentation des modules. Soumission documents aspects techniques, écriture des interfaces

Jusqu'au 22 avril : au moins la moitié la module est écrite

Jusqu'au 29 avril : Tests + si fini, passer à l'interface graphique

Jusqu'au 6 mai : Fin de la base du projet, début des fonctionnalités supplémentaires

Jusqu'au 13 mai : Fin interface graphique

Jusqu'au 20 mai : REDACTION COMPTE RENDU + SLIDES CAR 20 MAI SOUTENANCE



Modules :

- Affectation croisière : Lecture dans la structure de données directement (utilise les fonctions du module modèle)
- Affectation destination
- Module modèle : Crée la structure de données
- Module lecture du CSV et écriture dans structure de données
- Module écriture résultat dans un fichier
- Module affichage du résultat à partir d'un fichier créé par le module écriture écriture du résultat


Différentes structures de données:

- Information voyageurs : nom prénom, priorité (rajouter une colonne par rapport aux fichiers donnés), choix croisière, choix destination
- Information croisières: nom croisière, quota croisière, destinations
- Information destinations: nom, quota destination
- Contraintes
- Résultat des affectations des voyageurs aux différentes croisières: nom, prenom, croisière affectée, destinations affectées





