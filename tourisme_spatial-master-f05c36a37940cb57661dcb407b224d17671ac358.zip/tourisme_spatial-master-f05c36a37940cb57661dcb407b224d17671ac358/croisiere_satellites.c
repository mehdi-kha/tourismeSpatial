#include "modele.h"
void croisiere_satellites()
{
	FILE *fichier=fopen("croisiere_satellites.csv","r");

	croisiere c_satellites=croisiere("croisiere_satellite");

	char *planete=NULL,*quota=NULL;
	int c=0,compteur=0,k=0,i=0,j=0;
 	while((c=fgetc(fichier))!= EOF)
	{
		if((c!=',') && (c!='\n') && (k%2)==0)
		{
			planete=(char*)realloc(planete,(i+1)*sizeof(char));
            planete[i++]=c;
		}
        else if((c!=',') && (c!='\n') && (k%2)==1)
        {
            quota=(char*)realloc(quota,(j+1)*sizeof(char));
			quota[j++]=c;
		}
		else if((c==',') && (k%2==0))
		{
            k++;
		}
		else if((c==',') && (k%2!=0))
        {
             //Je suppose aussi que la fonction push existe.
            //(Elle permet d'ajouter une destination,un quota et aussi d'associer une zone à une destination)
            planete[i]='\0';
            quota[j]='\0';
            pushDestination(planete,atoi(quota),c_satellites,k%6);
            k++;
            i=0;
            j=0;
        }
	}
    free(planete);
    free(quota);
    fclose(fichier);
}
