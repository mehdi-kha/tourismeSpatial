#include "modele.h"
#include "string.h"
void contraintes()

{
	FILE *fichier=fopen("contraintes.csv","r");
	char *planete=NULL;
	char **unecontrainte=NULL;
	int c=0,compteur=0,k=0,i=0,j=0;
 	while((c=fgetc(fichier))!= EOF)
	{
		if((c!=',') && (c!='\n'))
		{
			planete=(char*)realloc(planete,(i+1)*sizeof(char));
            planete[i++]=c;
		}
		else if((c==',')&& (c!='\n'))
		{
		     //Je suppose aussi que la fonction pushContraintes existe.
            //(Elle permet d'ajouter une CONTRAINTE)
            planete[i]='\0';
            unecontrainte=(char**)realloc(unecontrainte,(j+1)*sizeof(char));
            *unecontrainte[k]=(char*)malloc((strlen(planete)+1)*sizeof(char));
            *unecontrainte[strlen(planete)]='\0';
            strcmp(*unecontrainte[k],planete)
            i=0;
            k++;
            j++;
		}
		else
        {
             //Je suppose que cette fonction existe
             pushContraintes(unecontrainte);
        }
	}
    free(planete);
    fclose(fichier);
}