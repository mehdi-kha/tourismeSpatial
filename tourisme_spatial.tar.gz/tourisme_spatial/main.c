#include <stdlib.h>
#include <stdio.h>
#include "creer_destinations.h"
#include "lecture_voyageur.h"
#include "./Modele/modele.h"
#include "lecture_voyageur.h"
#include "./destinations/destinations.h"
#include "./croisieres/croisieres.h"
#include "lecture_choix_contraintes.h"


int main(void){

croisieres cs = newCroisieres();
creer_destinations("./Sujet/destinations.csv","libre",cs);
creer_destinations("./Sujet/croisiere_planetes.csv","planetes",cs);
creer_destinations("./Sujet/croisiere_satellites.csv","satellites",cs);
creer_destinations("./Sujet/croisiere_vie.csv","vie",cs);




info_voyageur iv = infoVoyageur();
lecture_voyageur(iv);



choixVoyageurs(iv, cs);



creer_contraintes(cs); 

traitementVoyageurs(cs, iv); //Attribution des croisières aux voyageurs


traitementDestinations(cs);
FILE* fichier_final=NULL;
fichier_final=fopen("fichier_final.csv","w");
int numCrois=0;
voyageur currentVoyageur = NULL;
  croisiere currentCroisiere = get_first_croisiere_org(cs);
 while(currentCroisiere != NULL){ 
    numCrois++;
    currentVoyageur = get_first_voyageur(currentCroisiere);

    while(currentVoyageur != NULL){ 
      	fprintf(fichier_final,"%s,", get_nom_voyageur(currentVoyageur));
      	fprintf(fichier_final,"%s,", get_prenom_voyageur(currentVoyageur));
	fprintf(fichier_final,"%s,", get_croisiere_nom(currentCroisiere));
      	destination* choix = get_att_destination(currentVoyageur); 

			int i;
			for(i=0;i<6;i++){
				if(choix[i]==NULL){
					printf("err\n");
				}else{
					fprintf(fichier_final,"%s,",get_destination_nom(choix[i]));
				}
			}

      currentVoyageur = get_next_voyageur(currentCroisiere); //Traitement du voyageur suivant
      fprintf(fichier_final,"\n"); 
    }
    if(numCrois == 3)
      currentCroisiere = getCroisiere("libre", cs);
    else if(numCrois==4)
      break;
    else
      currentCroisiere = get_next_croisiere(cs); //Passage à la croisière suivante

  }

}
