#include "./Modele/modele.h"
void creer_destinations(char* nomfichier, char* nomcroisiere, croisieres cs);
 