#include "destinations.h"
 


void traitementDestinations(croisieres cs){

  destination* choixDestinations = NULL; /*Tableau de taille 24 qui contient les 6 choix de destinations du voyageur traité pour chaque zone de chaque croisière*/

  croisiere currentCroisiere = get_first_croisiere_org(cs); /*Donne la première croisière organisée*/
  voyageur currentVoyageur = NULL; //Va servir pour le parcours de tous les voyageurs pour chaque croisière

  destination* destAtt = NULL; /*Contient les destinations attribuées*/

  int i;
  int numCrois = 0; //Numéro de la croisière traitée (planete = 1; satellites = 2; vie = 3; libre = 4)
  
  while(currentCroisiere != NULL){ /*Traitement de toutes les croisières*/
    numCrois++;
    currentVoyageur = get_first_voyageur(currentCroisiere);
    while(currentVoyageur != NULL){ /*Traitement de chaque voyageur*/
      choixDestinations = get_choix_destination(currentVoyageur); /*Tableau des choix de destinations d'un voyageur - 24 colonnes (4 croisières * 6 zones)*/

      //Vérification des quotas et affectation des destinations

      for(i=6*(numCrois-1);i<6*numCrois;i++){ //Pour chaque zone
        	if(get_quota(currentCroisiere, choixDestinations[i])>0){ /*Cas où il reste de la place pour la destination pour la croisiere en question*/
        	  attribDest(currentVoyageur, choixDestinations[i], (i%6)+1); //(i%6)+1 est le numéro de la zone
        	}
	
        	else{
        	  attribDest(currentVoyageur, destinationLibre(currentCroisiere,(i%6)+1, NULL),(i%6)+1);
        	}
      }

      /*Verification des contraintes*/

      destAtt = get_att_destination(currentVoyageur); //Destinations attribuées à currentVoyageur
      for(i=0;i<6;i++){
	       if(getContrainte(destAtt[i])!=NULL)//S'il y a une contrainte pour une destination
	           traitementContrainte(currentVoyageur, destAtt[i], cs, currentCroisiere, destAtt);
      }
      
      currentVoyageur = get_next_voyageur(currentCroisiere); //Traitement du voyageur suivant
    }
    
    if(numCrois == 3)
      currentCroisiere = getCroisiere("libre", cs);
    else if(numCrois==4)
      break;
    else
      currentCroisiere = get_next_croisiere(cs); //Passage à la croisière suivante

  }


}




void traitementContrainte(voyageur currentVoyageur, destination currentDestination, croisieres cs, croisiere currentCroisiere, destination* destAtt){
  
  contrainte currentContrainte = getContrainte(currentDestination); //Contrainte correspondant à la destination currentDestination
  destination destContrainte = getDestinationContrainte(currentContrainte); //Destination correspondant à la contrainte currentContrainte
  int zoneContrainte;
  while(currentContrainte!=NULL){//Tant qu'il y a des contraintes
    if(get_quota(currentCroisiere, destContrainte)==0){//Cas où il n'y a pas de place dans la destination contrainte, on doit changer la destination qui contraint
      int zone = getZone(currentDestination, cs)+1; //+1 car getZone donne l'indice de la zone et non la zone
      attribDest(currentVoyageur, destinationLibre(currentCroisiere, zone, currentDestination), zone); //currentDestination est interdite
      break;
    }
    zoneContrainte = getZone(destContrainte, cs); //Indice de la zone contrainte
    supprDestAtt(destAtt[zoneContrainte], currentCroisiere);//Incrémentation du nombre de places disponibles pour la destination
    attribDest(currentVoyageur, destContrainte, zoneContrainte+1); //modification de l'affectation des destinations
    currentContrainte = getNextContrainte(currentContrainte);
  }
}


destination destinationLibre(croisiere curCroisiere, int curZone, destination interdite){
  
  int sizeTabDest = get_nb_dest_crois(curCroisiere, curZone); /*Nombre de destinations pour la zone curZone de curCroisiere */
  destination* tabDest; //Contient les destinations de la zone curZone
  tabDest = get_dest_zone(curCroisiere, curZone);
  destination d = tabDest[0];
  int i = 0;
  while(get_quota(curCroisiere, d)==0 && i<sizeTabDest){
    i=i+1;
    d = tabDest[i];
    if(get_quota(curCroisiere, d)!=0 && d!=interdite) /*Si il y a de la place dans d pour la croisière curCrois*/
      return d;
  }
  return NULL;
  
}
