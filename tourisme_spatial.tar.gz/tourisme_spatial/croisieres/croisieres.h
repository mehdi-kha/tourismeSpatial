#include <stdlib.h>
#include <stdio.h>
#include "../Modele/modele.h"

void traitementVoyageurs(croisieres cs, info_voyageur iv);

 