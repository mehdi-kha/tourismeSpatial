#include "./Modele/modele.h" 
void lecture_voyageur(info_voyageur iv);
